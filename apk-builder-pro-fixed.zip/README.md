# پروژه مادر و قالب رسمی Android Studio برای ساخت APK
## Official Android Studio WebView & Tapsell Mother Template (AirTube)

این پروژه یک ساختار استاندارد، کاملاً واقعی و قابل Build برای **Android Studio** و سیستم‌های CI/CD (مانند **GitHub Actions**) است که به عنوان Template اصلی برای تبدیل وب‌سایت‌ها، ویدیوها و اسناد HTML5 محلی به فایل APK واقعی اندروید طراحی شده است.

---

### ۱. معرفی پروژه (Overview)
این پروژه بر پایه:
- **زبان:** Kotlin و AndroidX
- **محیط توسعه:** Android Studio (سازگار با نسخه‌های Koala, Ladybug, Meerkat و بالاتر)
- **موتور ساخت:** Gradle 8 / 9 با Android Gradle Plugin (AGP) 9.x
- **پشتیبانی از JDK:** کامپایل رسمی با Java / JDK 17
- **موتور وب پیشرفته:** `WebView` با شتاب سخت‌افزاری، کوکی‌ها، حافظه محلی (DOM / LocalStorage)، جاوااسکریپت، پخش ویدیوی تمام‌صفحه (Fullscreen Web Video)، مدیریت هوشمند دکمه بازگشت (Back Navigation) و مجوزهای وب WebRTC.
- **شبکه تبلیغاتی:** ادغام استاندارد **Tapsell Plus SDK** برای بنر استاندارد، تبلیغات بین‌برنامه‌ای (Interstitial) و ویدیوی جایزه‌ای (Rewarded).

---

### ۲. نحوه باز کردن پروژه در Android Studio
1. فایل `android-webview-template.zip` را در یک پوشه دلخواه استخراج (Extract) کنید.
2. نرم‌افزار **Android Studio** را اجرا کنید.
3. از منوی شروع، روی گزینه **Open** کلیک کنید.
4. پوشه پروژه را انتخاب کرده و روی **OK** کلیک کنید.
5. منتظر بمانید تا فرآیند **Gradle Sync** انجام شود و وابستگی‌ها دانلود شوند.

---

### ۳. نحوه ساخت و خروجی گرفتن (Build)
#### ساخت فایل Release APK با خط فرمان:
```bash
./gradlew assembleRelease
```
یا در ویندوز:
```cmd
gradlew.bat assembleRelease
```

#### ساخت فایل Debug APK جهت تست سریع:
```bash
./gradlew assembleDebug
```

---

### ۴. نحوه تغییر آدرس وب (URL)
در فایل پیکربندی مرکزی `app-config.json` در ریشه پروژه یا `app/src/main/assets/app-config.json` مقدار `sourceType` و `url` را مشخص کنید:
```json
{
  "sourceType": "URL",
  "url": "https://yourwebsite.com"
}
```
همچنین می‌توانید در زمان Build از طریق پارامتر Gradle این مقدار را بدون دستکاری کد تغییر دهید:
```bash
./gradlew assembleRelease -PsourceType=URL -PappUrl="https://yourwebsite.com"
```

---

### ۵. نحوه تغییر نام برنامه (App Name)
در فایل `app-config.json`:
```json
{
  "appName": "نام دلخواه برنامه"
}
```
یا با پارامتر خط فرمان Gradle:
```bash
./gradlew assembleRelease -PappName="نام دلخواه برنامه"
```
نام برنامه به صورت خودکار در لایه Manifest (`android:label="${appName}"`) و رشته‌های برنامه اعمال می‌شود.

---

### ۶. نحوه تغییر Package ID / Application ID
در فایل `app-config.json`:
```json
{
  "appId": "com.company.newapp"
}
```
یا با دستور:
```bash
./gradlew assembleRelease -PappId="com.company.newapp"
```
این مقدار مستقیماً به عنوان `applicationId` رسمی در لایه `defaultConfig` گرادل اعمال می‌گردد.

---

### ۷. نحوه تغییر آیکون سفارشی (Custom App Icon)
برای تغییر آیکون برنامه، فایل‌های تصویری با رزولوشن‌های استاندارد اندروید را در پوشه‌های زیر جایگزین نمایید:
- `app/src/main/res/mipmap-mdpi/ic_launcher.png` (48x48 px)
- `app/src/main/res/mipmap-hdpi/ic_launcher.png` (72x72 px)
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png` (96x96 px)
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png` (144x144 px)
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` (192x192 px)
- و برای آیکون‌های گرد: `ic_launcher_round.png` در همان پوشه‌ها.
- برای اندروید ۸ به بالا (Adaptive Icons)، فایل‌های لایه در `mipmap-anydpi-v26/` قرار دارند.

---

### ۸. نحوه تغییر شماره و نام نسخه (Version)
در فایل `app-config.json`:
```json
{
  "versionName": "1.0.1",
  "versionCode": 2
}
```
یا با پارامترهای خط فرمان:
```bash
./gradlew assembleRelease -PversionName="1.0.1" -PversionCode=2
```

---

### ۹. نحوه تنظیم تبلیغات تپسل (Tapsell)
در فایل `app-config.json`:
```json
{
  "tapsell": {
    "enabled": true,
    "appKey": "کلید_اپلیکیشن_تپسل_شما",
    "bannerZoneId": "شناسه_زون_بنر",
    "interstitialZoneId": "شناسه_زون_بین_برنامه‌ای",
    "rewardedZoneId": "شناسه_زون_جایزه‌ای"
  }
}
```
- در صورت تنظیم `"enabled": false`، بنر و تبلیغات به طور کامل غیرفعال و مخفی خواهند شد.

---

### ۱۰. اجرای خودکار در GitHub Actions
یک گردش کار کامل در مسیر `.github/workflows/build-apk.yml` قرار داده شده است.
- با هر Push به شاخه `main` یا اجرای دستی از تب **Actions** با انتخاب گزینه **Run workflow** اجرا می‌شود.
- می‌توانید متغیرهای `app_name`, `app_id`, `version_name`, `version_code`, `source_type` و `app_url` را مستقیماً در فرم GitHub Actions وارد کنید.
- برای امضای رسمی Release، مقادیر زیر را در بخش **Settings > Secrets and variables > Actions** مخزن GitHub اضافه کنید:
  - `KEYSTORE_BASE64`: محتوای فایل Keystore به فرمت Base64
  - `KEYSTORE_PASSWORD`: رمز فایل Keystore
  - `KEY_ALIAS`: نام کلید (Alias)
  - `KEY_PASSWORD`: رمز کلید اختصاصی

---

### ۱۱. محل قرارگیری فایل APK خروجی
پس از اجرای موفقیت‌آمیز دستور ساخت:
- در محیط محلی:
  `app/build/outputs/apk/release/app-release.apk`
  یا در بیلد دیباگ:
  `app/build/outputs/apk/debug/app-debug.apk`
- در GitHub Actions:
  در بخش **Artifacts** صفحه اجرا با نام `app-release.apk` قابل دانلود مستقیم است.
