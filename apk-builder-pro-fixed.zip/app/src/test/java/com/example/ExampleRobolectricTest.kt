package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.generator.CodeTemplateGenerator
import com.example.model.ApkProjectConfig
import com.example.model.AppPermission
import com.example.model.AppSourceType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AirTube", appName)
  }

  @Test
  fun `code generator generates valid kotlin activity with tapsell and webview`() {
    val config = ApkProjectConfig(
      appName = "Test App",
      packageName = "com.test.app",
      sourceType = AppSourceType.PUBLIC_URL,
      sourceUrl = "https://example.com",
      permissions = setOf(AppPermission.INTERNET, AppPermission.RECORD_AUDIO, AppPermission.CAMERA)
    )

    val ktCode = CodeTemplateGenerator.generateKotlinActivity(config)
    assertTrue(ktCode.contains("class MainActivity : AppCompatActivity()"))
    assertTrue(ktCode.contains("TapsellPlus.initialize"))
    assertTrue(ktCode.contains("Manifest.permission.RECORD_AUDIO"))
    assertTrue(ktCode.contains("https://example.com"))

    val manifestXml = CodeTemplateGenerator.generateManifest(config)
    assertTrue(manifestXml.contains("android.permission.RECORD_AUDIO"))
    assertTrue(manifestXml.contains("android.permission.CAMERA"))
  }
}
