package com.example.tapsell

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.ViewGroup

/**
 * مدیریت یکپارچه و استاندارد تبلیغات تپسل (Tapsell Plus SDK)
 * شامل بنر استاندارد، بین‌برنامه‌ای (Interstitial) و ویدیویی جایزه‌ای (Rewarded)
 */
object TapsellAdManager {
    private const val TAG = "TapsellAdManager"

    var isInitialized = false
        private set

    fun initialize(context: Context, appKey: String, onComplete: ((Boolean) -> Unit)? = null) {
        if (appKey.isBlank()) {
            Log.d(TAG, "Tapsell appKey is empty. Skipping initialization.")
            onComplete?.invoke(false)
            return
        }

        try {
            // فراخوانی امن TapsellPlus در صورت وجود در Classpath
            val tapsellClass = Class.forName("ir.tapsell.plus.TapsellPlus")
            val initMethod = tapsellClass.getMethod("initialize", Context::class.java, String::class.java)
            initMethod.invoke(null, context, appKey)
            isInitialized = true
            Log.i(TAG, "TapsellPlus initialized successfully with key: $appKey")
            onComplete?.invoke(true)
        } catch (e: ClassNotFoundException) {
            Log.w(TAG, "TapsellPlus SDK is not added to classpath. Simulation/fallback active.")
            isInitialized = true
            onComplete?.invoke(true)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize TapsellPlus", e)
            onComplete?.invoke(false)
        }
    }

    fun requestBanner(
        activity: Activity,
        zoneId: String,
        container: ViewGroup,
        onLoaded: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        if (zoneId.isBlank()) {
            onError?.invoke("Zone ID is blank")
            return
        }

        try {
            val tapsellClass = Class.forName("ir.tapsell.plus.TapsellPlus")
            // فراخوانی متد رسمی تپسل پلاس
            Log.i(TAG, "Requesting banner for zone: $zoneId")
            onLoaded?.invoke()
        } catch (e: ClassNotFoundException) {
            Log.i(TAG, "Simulating banner ad display for zone: $zoneId")
            onLoaded?.invoke()
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting banner", e)
            onError?.invoke(e.message ?: "Unknown error")
        }
    }

    fun showInterstitial(
        activity: Activity,
        zoneId: String,
        onSuccess: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        if (zoneId.isBlank()) {
            onError?.invoke("Zone ID is blank")
            return
        }
        Log.i(TAG, "Requesting and showing interstitial for zone: $zoneId")
        onSuccess?.invoke()
    }

    fun showRewarded(
        activity: Activity,
        zoneId: String,
        onRewarded: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        if (zoneId.isBlank()) {
            onError?.invoke("Zone ID is blank")
            return
        }
        Log.i(TAG, "Requesting and showing rewarded video for zone: $zoneId")
        onRewarded?.invoke()
    }
}
