package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.generator.ApkBuilderEngine
import com.example.generator.ProjectZipExporter
import com.example.model.ApkProjectConfig
import com.example.model.AppPermission
import com.example.model.AppSourceType
import com.example.model.GeneratedApkItem
import com.example.model.LanguageType
import com.example.model.TapsellConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class ApkBuilderViewModel(application: Application) : AndroidViewModel(application) {

    private val _config = MutableStateFlow(ApkProjectConfig())
    val config: StateFlow<ApkProjectConfig> = _config.asStateFlow()

    private val _generatedItems = MutableStateFlow<List<GeneratedApkItem>>(emptyList())
    val generatedItems: StateFlow<List<GeneratedApkItem>> = _generatedItems.asStateFlow()

    private val _isBuilding = MutableStateFlow(false)
    val isBuilding: StateFlow<Boolean> = _isBuilding.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isPreviewActive = MutableStateFlow(false)
    val isPreviewActive: StateFlow<Boolean> = _isPreviewActive.asStateFlow()

    private val _isCodeViewerActive = MutableStateFlow(false)
    val isCodeViewerActive: StateFlow<Boolean> = _isCodeViewerActive.asStateFlow()

    init {
        loadExistingOutputs()
    }

    fun updateAppName(name: String) {
        val sanitizedPkg = name.trim().lowercase()
            .replace("[^a-z0-9]".toRegex(), "")
            .ifBlank { "myapp" }
        _config.value = _config.value.copy(
            appName = name,
            packageName = "com.$sanitizedPkg.app"
        )
    }

    fun updatePackageName(pkg: String) {
        _config.value = _config.value.copy(packageName = pkg)
    }

    fun updateVersionName(ver: String) {
        _config.value = _config.value.copy(versionName = ver)
    }

    fun updateSourceType(type: AppSourceType) {
        _config.value = _config.value.copy(sourceType = type)
    }

    fun updateSourceUrl(url: String) {
        _config.value = _config.value.copy(sourceUrl = url)
    }

    fun updateHtmlContent(html: String) {
        _config.value = _config.value.copy(htmlContent = html)
    }

    fun updateLanguage(lang: LanguageType) {
        _config.value = _config.value.copy(language = lang)
    }

    fun togglePermission(permission: AppPermission) {
        val current = _config.value.permissions.toMutableSet()
        if (current.contains(permission)) {
            current.remove(permission)
        } else {
            current.add(permission)
        }
        _config.value = _config.value.copy(permissions = current)
    }

    fun updateTapsellEnabled(enabled: Boolean) {
        _config.value = _config.value.copy(
            tapsellConfig = _config.value.tapsellConfig.copy(enabled = enabled)
        )
    }

    fun updateTapsellAppKey(key: String) {
        _config.value = _config.value.copy(
            tapsellConfig = _config.value.tapsellConfig.copy(appKey = key)
        )
    }

    fun updateTapsellBannerZone(zoneId: String) {
        _config.value = _config.value.copy(
            tapsellConfig = _config.value.tapsellConfig.copy(bannerZoneId = zoneId)
        )
    }

    fun updateTapsellInterstitialZone(zoneId: String) {
        _config.value = _config.value.copy(
            tapsellConfig = _config.value.tapsellConfig.copy(interstitialZoneId = zoneId)
        )
    }

    fun updateHardwareAcceleration(enabled: Boolean) {
        _config.value = _config.value.copy(enableHardwareAcceleration = enabled)
    }

    fun updateJavaScript(enabled: Boolean) {
        _config.value = _config.value.copy(enableJavaScript = enabled)
    }

    fun updateAllowFileAccess(enabled: Boolean) {
        _config.value = _config.value.copy(allowFileAccess = enabled)
    }

    fun updateCustomLogoName(logoName: String) {
        _config.value = _config.value.copy(customLogoName = logoName)
    }

    fun setPreviewActive(active: Boolean) {
        _isPreviewActive.value = active
    }

    fun setCodeViewerActive(active: Boolean) {
        _isCodeViewerActive.value = active
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun buildApk() {
        viewModelScope.launch(Dispatchers.IO) {
            _isBuilding.value = true
            _statusMessage.value = "در حال ساخت پکیج و کامپایل فایل APK..."
            try {
                val item = ApkBuilderEngine.buildApk(getApplication(), _config.value)
                val updated = _generatedItems.value.toMutableList()
                updated.add(0, item)
                _generatedItems.value = updated
                _statusMessage.value = "فایل APK با موفقیت ساخته شد: ${item.fileName}"
            } catch (e: Exception) {
                _statusMessage.value = "خطا در تولید APK: ${e.message}"
            } finally {
                _isBuilding.value = false
            }
        }
    }

    fun exportProjectZip() {
        viewModelScope.launch(Dispatchers.IO) {
            _isBuilding.value = true
            _statusMessage.value = "در حال ایجاد سورس‌کد کامل پروژه اندروید (ZIP)..."
            try {
                val file = ProjectZipExporter.exportProjectZip(getApplication(), _config.value)
                val item = GeneratedApkItem(
                    id = "zip_${System.currentTimeMillis()}",
                    appName = _config.value.appName,
                    packageName = _config.value.packageName,
                    fileName = file.name,
                    filePath = file.absolutePath,
                    fileSizeFormatted = "${file.length() / 1024} کیلوبایت",
                    timestamp = System.currentTimeMillis(),
                    isApk = false
                )
                val updated = _generatedItems.value.toMutableList()
                updated.add(0, item)
                _generatedItems.value = updated
                _statusMessage.value = "سورس پروژه با موفقیت در قالب ZIP صادر شد."
            } catch (e: Exception) {
                _statusMessage.value = "خطا در ایجاد پروژه: ${e.message}"
            } finally {
                _isBuilding.value = false
            }
        }
    }

    fun deleteItem(item: GeneratedApkItem) {
        val file = File(item.filePath)
        if (file.exists()) file.delete()
        _generatedItems.value = _generatedItems.value.filter { it.id != item.id }
    }

    private fun loadExistingOutputs() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = mutableListOf<GeneratedApkItem>()
            val apksDir = File(getApplication<Application>().filesDir, "generated_apks")
            if (apksDir.exists()) {
                apksDir.listFiles()?.filter { it.name.endsWith(".apk") }?.forEach { f ->
                    list.add(
                        GeneratedApkItem(
                            id = f.name,
                            appName = f.name.substringBefore("_v"),
                            packageName = "com.app.webview",
                            fileName = f.name,
                            filePath = f.absolutePath,
                            fileSizeFormatted = "${f.length() / 1024} کیلوبایت",
                            timestamp = f.lastModified(),
                            isApk = true
                        )
                    )
                }
            }

            val zipDir = File(getApplication<Application>().cacheDir, "exported_projects")
            if (zipDir.exists()) {
                zipDir.listFiles()?.filter { it.name.endsWith(".zip") }?.forEach { f ->
                    list.add(
                        GeneratedApkItem(
                            id = f.name,
                            appName = f.name.substringBefore("_SourceCode"),
                            packageName = "com.app.source",
                            fileName = f.name,
                            filePath = f.absolutePath,
                            fileSizeFormatted = "${f.length() / 1024} کیلوبایت",
                            timestamp = f.lastModified(),
                            isApk = false
                        )
                    )
                }
            }

            list.sortByDescending { it.timestamp }
            _generatedItems.value = list
        }
    }
}
