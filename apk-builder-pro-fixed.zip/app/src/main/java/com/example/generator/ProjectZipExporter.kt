package com.example.generator

import android.content.Context
import com.example.model.ApkProjectConfig
import com.example.model.AppSourceType
import com.example.model.LanguageType
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ProjectZipExporter {

    fun exportProjectZip(context: Context, config: ApkProjectConfig): File {
        val projectsDir = File(context.cacheDir, "exported_projects")
        if (!projectsDir.exists()) projectsDir.mkdirs()

        val cleanAppName = config.appName.replace("\\s+".toRegex(), "_")
        val zipFile = File(projectsDir, "${cleanAppName}_SourceCode.zip")
        if (zipFile.exists()) zipFile.delete()

        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            // Root files
            addZipEntry(zos, "settings.gradle.kts", CodeTemplateGenerator.generateSettingsGradleKts(config))
            addZipEntry(zos, "build.gradle.kts", """
// Top-level build file
plugins {
    id("com.android.application") version "8.3.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
            """.trimIndent())
            addZipEntry(zos, "gradle.properties", "android.useAndroidX=true\nandroid.enableJetifier=true\norg.gradle.jvmargs=-Xmx2048m")

            // App module
            addZipEntry(zos, "app/build.gradle.kts", CodeTemplateGenerator.generateAppBuildGradleKts(config))
            addZipEntry(zos, "app/src/main/AndroidManifest.xml", CodeTemplateGenerator.generateManifest(config))
            addZipEntry(zos, "app/src/main/res/layout/activity_main.xml", CodeTemplateGenerator.generateLayoutXml())
            addZipEntry(zos, "app/src/main/res/values/strings.xml", """
<resources>
    <string name="app_name">${config.appName}</string>
</resources>
            """.trimIndent())
            addZipEntry(zos, "app/src/main/res/values/colors.xml", """
<resources>
    <color name="primary">#0284C7</color>
    <color name="primary_dark">#0369A1</color>
    <color name="accent">#10B981</color>
</resources>
            """.trimIndent())

            // Java / Kotlin code
            val packagePath = config.packageName.replace('.', '/')
            if (config.language == LanguageType.KOTLIN) {
                val ktCode = CodeTemplateGenerator.generateKotlinActivity(config)
                addZipEntry(zos, "app/src/main/java/$packagePath/MainActivity.kt", ktCode)
            } else {
                val javaCode = CodeTemplateGenerator.generateJavaActivity(config)
                addZipEntry(zos, "app/src/main/java/$packagePath/MainActivity.java", javaCode)
            }

            // Web assets
            val htmlContent = if (config.sourceType == AppSourceType.PUBLIC_URL) {
                """
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="0; url=${config.sourceUrl}">
  <title>${config.appName}</title>
</head>
<body style="background:#000;color:#fff;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;">
  <p>در حال انتقال به ${config.sourceUrl}...</p>
</body>
</html>
                """.trimIndent()
            } else {
                config.htmlContent
            }
            addZipEntry(zos, "app/src/main/assets/index.html", htmlContent)

            // Config metadata
            val configJson = """
{
  "appName": "${config.appName}",
  "packageName": "${config.packageName}",
  "versionName": "${config.versionName}",
  "versionCode": ${config.versionCode},
  "sourceType": "${config.sourceType.name}",
  "tapsellEnabled": ${config.tapsellConfig.enabled},
  "tapsellAppKey": "${config.tapsellConfig.appKey}",
  "hardwareAcceleration": ${config.enableHardwareAcceleration}
}
            """.trimIndent()
            addZipEntry(zos, "app/src/main/assets/app_config.json", configJson)

            // README
            val readme = """
# پروژه اندروید ${config.appName}
این سورس‌کد به صورت خودکار توسط APK Builder تولید شده است.

## نحوه اجرا در Android Studio:
1. پوشه را از حالت فشرده خارج کنید (Extract Zip).
2. برنامه Android Studio را باز کرده و گزینه "Open" را بزنید.
3. پوشه پروژه را انتخاب کرده و منتظر همگام‌سازی Gradle بمانید.
4. برای تولید فایل نهایی، از منوی Build > Generate Signed Bundle / APK اقدام فرمایید.

## تنظیمات تبلیغات تپسل:
- کلید تپسل: ${config.tapsellConfig.appKey}
- شناسه تبلیغ بنری: ${config.tapsellConfig.bannerZoneId}
- شناسه تبلیغ بین‌برنامه‌ای: ${config.tapsellConfig.interstitialZoneId}
- مخزن Tapsell Maven در settings.gradle.kts اضافه شده است.
            """.trimIndent()
            addZipEntry(zos, "README.md", readme)
        }

        return zipFile
    }

    private fun addZipEntry(zos: ZipOutputStream, entryName: String, content: String) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }
}
