package com.example.generator

import com.example.model.ApkProjectConfig
import com.example.model.AppPermission
import com.example.model.AppSourceType
import com.example.model.LanguageType

object CodeTemplateGenerator {

    fun generateManifest(config: ApkProjectConfig): String {
        val permissionsXml = config.permissions.joinToString("\n    ") {
            "<uses-permission android:name=\"${it.permissionString}\" />"
        }

        return """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${config.packageName}">

    $permissionsXml

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:hardwareAccelerated="${config.enableHardwareAcceleration}"
        android:usesCleartextTraffic="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:theme="@style/Theme.AppCompat.Light.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
        """.trimIndent()
    }

    fun generateKotlinActivity(config: ApkProjectConfig): String {
        val pkg = config.packageName
        val hasMic = config.permissions.contains(AppPermission.RECORD_AUDIO)
        val hasCamera = config.permissions.contains(AppPermission.CAMERA)
        val hasTapsell = config.tapsellConfig.enabled

        val tapsellInit = if (hasTapsell) {
            """
        // Initialize Tapsell Plus SDK
        TapsellPlus.initialize(this, "${config.tapsellConfig.appKey}")
        TapsellPlus.setDebugMode(Log.DEBUG)

        // Request & Show Standard Banner Ad
        setupTapsellBanner()
            """.trimIndent()
        } else {
            "// Tapsell SDK is disabled in settings"
        }

        val tapsellMethods = if (hasTapsell) {
            """
    private fun setupTapsellBanner() {
        val bannerContainer = findViewById<android.widget.FrameLayout>(R.id.tapsellBannerContainer)
        TapsellPlus.requestStandardBannerRule(
            this,
            "${config.tapsellConfig.bannerZoneId}",
            TapsellPlusBannerType.BANNER_320x50,
            object : AdRequestCallback() {
                override fun response(tapsellPlusAdModel: TapsellPlusAdModel?) {
                    tapsellPlusAdModel?.let { model ->
                        TapsellPlus.showStandardBannerRule(
                            this@MainActivity,
                            model.responseId,
                            bannerContainer,
                            object : AdShowListener() {
                                override fun onOpened() {
                                    Log.d("Tapsell", "Banner Ad opened")
                                }
                                override fun onError(error: TapsellPlusError?) {
                                    Log.e("Tapsell", "Banner Ad error: " + error?.message)
                                }
                            }
                        )
                    }
                }
                override fun error(message: String?) {
                    Log.e("Tapsell", "Failed to request banner: " + message)
                }
            }
        )
    }

    fun showInterstitialAd() {
        TapsellPlus.requestInterstitial(
            this,
            "${config.tapsellConfig.interstitialZoneId}",
            object : AdRequestCallback() {
                override fun response(adModel: TapsellPlusAdModel?) {
                    adModel?.let {
                        TapsellPlus.showInterstitial(this@MainActivity, it.responseId, object : AdShowListener() {})
                    }
                }
                override fun error(message: String?) {
                    Log.e("Tapsell", "Interstitial error: " + message)
                }
            }
        )
    }
            """.trimIndent()
        } else {
            ""
        }

        val urlToLoad = when (config.sourceType) {
            AppSourceType.PUBLIC_URL -> "\"${config.sourceUrl}\""
            AppSourceType.HTML_CODE, AppSourceType.HTML_FILE -> "\"file:///android_asset/index.html\""
            AppSourceType.PROJECT_ZIP -> "\"file:///android_asset/index.html\""
        }

        return """
package $pkg

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
${if (hasTapsell) "import ir.tapsell.plus.*\nimport ir.tapsell.plus.model.*\n" else ""}

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private var customVideoView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private lateinit var fullscreenContainer: FrameLayout

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)

        setupWebView()
        requestAppPermissions()

        $tapsellInit

        // Load Content (URL or HTML)
        webView.loadUrl($urlToLoad)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = ${config.enableJavaScript}
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = ${config.allowFileAccess}
        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        ${if (config.userAgentDesktop) "settings.userAgentString = \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\"" else ""}

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }

            // HTML5 Fullscreen Video Support
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customVideoView != null) {
                    onHideCustomView()
                    return
                }
                customVideoView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.visibility = View.VISIBLE
                webView.visibility = View.GONE
            }

            override fun onHideCustomView() {
                fullscreenContainer.visibility = View.GONE
                fullscreenContainer.removeView(customVideoView)
                customVideoView = null
                customViewCallback?.onCustomViewHidden()
                webView.visibility = View.VISIBLE
            }

            // Handle Camera/Microphone requests from WebRTC
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let {
                    val requestedResources = it.resources
                    it.grant(requestedResources)
                }
            }
        }
    }

    private fun requestAppPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        ${if (hasMic) "if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)" else ""}
        ${if (hasCamera) "if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) permissionsToRequest.add(Manifest.permission.CAMERA)" else ""}
        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), 101)
        }
    }

    $tapsellMethods

    override fun onBackPressed() {
        if (customVideoView != null) {
            webView.webChromeClient?.onHideCustomView()
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
        """.trimIndent()
    }

    fun generateJavaActivity(config: ApkProjectConfig): String {
        val pkg = config.packageName
        val hasMic = config.permissions.contains(AppPermission.RECORD_AUDIO)
        val hasCamera = config.permissions.contains(AppPermission.CAMERA)
        val hasTapsell = config.tapsellConfig.enabled

        val tapsellInit = if (hasTapsell) {
            """
        // Tapsell Plus SDK Initialization
        TapsellPlus.initialize(this, "${config.tapsellConfig.appKey}");
        setupTapsellBanner();
            """.trimIndent()
        } else {
            "// Tapsell SDK disabled"
        }

        val urlToLoad = when (config.sourceType) {
            AppSourceType.PUBLIC_URL -> "\"${config.sourceUrl}\""
            else -> "\"file:///android_asset/index.html\""
        }

        return """
package $pkg;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;
${if (hasTapsell) "import ir.tapsell.plus.*;\nimport ir.tapsell.plus.model.*;\n" else ""}

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private View customVideoView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private FrameLayout fullscreenContainer;

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);

        setupWebView();
        requestAppPermissions();

        $tapsellInit

        webView.loadUrl($urlToLoad);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(${config.enableJavaScript});
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(${config.allowFileAccess});
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customVideoView != null) {
                    onHideCustomView();
                    return;
                }
                customVideoView = view;
                customViewCallback = callback;
                fullscreenContainer.addView(view, new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                fullscreenContainer.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                fullscreenContainer.setVisibility(View.GONE);
                fullscreenContainer.removeView(customVideoView);
                customVideoView = null;
                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                }
                webView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (request != null) {
                    request.grant(request.getResources());
                }
            }
        });
    }

    private void requestAppPermissions() {
        List<String> list = new ArrayList<>();
        ${if (hasMic) "if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) list.add(Manifest.permission.RECORD_AUDIO);" else ""}
        ${if (hasCamera) "if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) list.add(Manifest.permission.CAMERA);" else ""}
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(this, list.toArray(new String[0]), 101);
        }
    }

    ${if (hasTapsell) """
    private void setupTapsellBanner() {
        FrameLayout bannerContainer = findViewById(R.id.tapsellBannerContainer);
        TapsellPlus.requestStandardBannerRule(
                this,
                "${config.tapsellConfig.bannerZoneId}",
                TapsellPlusBannerType.BANNER_320x50,
                new AdRequestCallback() {
                    @Override
                    public void response(TapsellPlusAdModel tapsellPlusAdModel) {
                        TapsellPlus.showStandardBannerRule(
                                MainActivity.this,
                                tapsellPlusAdModel.getResponseId(),
                                bannerContainer,
                                new AdShowListener() {}
                        );
                    }

                    @Override
                    public void error(String message) {
                        Log.e("Tapsell", "Banner error: " + message);
                    }
                }
        );
    }
    """ else ""}

    @Override
    public void onBackPressed() {
        if (customVideoView != null) {
            webView.getWebChromeClient().onHideCustomView();
        } else if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
        """.trimIndent()
    }

    fun generateLayoutXml(): String {
        return """
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <ProgressBar
        android:id="@+id/progressBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="0dp"
        android:layout_height="4dp"
        android:indeterminate="false"
        android:max="100"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <WebView
        android:id="@+id/webView"
        android:layout_width="0dp"
        android:layout_height="0dp"
        app:layout_constraintBottom_toTopOf="@+id/tapsellBannerContainer"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@+id/progressBar" />

    <!-- Tapsell Standard Banner Container -->
    <FrameLayout
        android:id="@+id/tapsellBannerContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:minHeight="50dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

    <!-- Fullscreen Video Container -->
    <FrameLayout
        android:id="@+id/fullscreenContainer"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="#000000"
        android:visibility="gone" />

</androidx.constraintlayout.widget.ConstraintLayout>
        """.trimIndent()
    }

    fun generateAppBuildGradleKts(config: ApkProjectConfig): String {
        val hasTapsell = config.tapsellConfig.enabled
        return """
plugins {
    id("com.android.application")
    ${if (config.language == LanguageType.KOTLIN) "id(\"org.jetbrains.kotlin.android\")" else ""}
}

android {
    namespace = "${config.packageName}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${config.packageName}"
        minSdk = 21
        targetSdk = 34
        versionCode = ${config.versionCode}
        versionName = "${config.versionName}"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.webkit:webkit:1.10.0")

    ${if (hasTapsell) """
    // Tapsell Plus SDK
    implementation("ir.tapsell.plus:tapsell-plus-sdk:2.2.4")
    """ else ""}
}
        """.trimIndent()
    }

    fun generateSettingsGradleKts(config: ApkProjectConfig): String {
        return """
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Tapsell Maven Repository
        maven { url = java.net.URI("https://repo.tapsell.ir/content/repositories/releases/") }
    }
}

rootProject.name = "${config.appName}"
include(":app")
        """.trimIndent()
    }
}
