document.addEventListener('DOMContentLoaded', () => {
  // Theme Toggle
  const themeToggle = document.getElementById('theme-toggle');
  let currentTheme = localStorage.getItem('app_theme') || 'dark';
  document.body.setAttribute('data-theme', currentTheme);

  themeToggle.addEventListener('click', () => {
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.body.setAttribute('data-theme', currentTheme);
    localStorage.setItem('app_theme', currentTheme);
  });

  // Video Controls & Fullscreen
  const video = document.getElementById('sample-video');
  const btnPlayPause = document.getElementById('btn-play-pause');
  const btnFullscreen = document.getElementById('btn-fullscreen');

  btnPlayPause.addEventListener('click', () => {
    if (video.paused) {
      video.play();
      btnPlayPause.textContent = '⏸ توقف موقت';
    } else {
      video.pause();
      btnPlayPause.textContent = '▶ پخش';
    }
  });

  btnFullscreen.addEventListener('click', () => {
    if (video.requestFullscreen) {
      video.requestFullscreen();
    } else if (video.webkitRequestFullscreen) {
      video.webkitRequestFullscreen();
    } else if (video.mozRequestFullScreen) {
      video.mozRequestFullScreen();
    } else if (video.msRequestFullscreen) {
      video.msRequestFullscreen();
    }
  });

  // LocalStorage Counter
  const counterVal = document.getElementById('counter-value');
  const btnIncrement = document.getElementById('btn-increment');
  const btnReset = document.getElementById('btn-reset');

  let count = parseInt(localStorage.getItem('app_counter') || '0', 10);
  counterVal.textContent = count;

  btnIncrement.addEventListener('click', () => {
    count += 1;
    counterVal.textContent = count;
    localStorage.setItem('app_counter', count.toString());
  });

  btnReset.addEventListener('click', () => {
    count = 0;
    counterVal.textContent = count;
    localStorage.setItem('app_counter', '0');
  });

  // Media Permissions: Camera & Mic
  const btnCamera = document.getElementById('btn-camera');
  const btnMic = document.getElementById('btn-mic');
  const mediaPreview = document.getElementById('media-preview');
  const cameraStream = document.getElementById('camera-stream');
  const btnStopStream = document.getElementById('btn-stop-stream');
  let activeStream = null;

  btnCamera.addEventListener('click', async () => {
    try {
      if (activeStream) {
        activeStream.getTracks().forEach(track => track.stop());
      }
      activeStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      cameraStream.srcObject = activeStream;
      mediaPreview.classList.remove('hidden');
    } catch (err) {
      alert('خطا در دسترسی به دوربین: ' + err.message);
    }
  });

  btnMic.addEventListener('click', async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      alert('دسترسی میکروفون با موفقیت تأیید شد!');
      stream.getTracks().forEach(track => track.stop());
    } catch (err) {
      alert('خطا در دسترسی به میکروفون: ' + err.message);
    }
  });

  btnStopStream.addEventListener('click', () => {
    if (activeStream) {
      activeStream.getTracks().forEach(track => track.stop());
      activeStream = null;
    }
    mediaPreview.classList.add('hidden');
  });

  // System Diagnostics
  const infoUa = document.getElementById('info-ua');
  const infoStorage = document.getElementById('info-storage');
  const infoOnline = document.getElementById('info-online');

  infoUa.textContent = navigator.userAgent.includes('wv') || navigator.userAgent.includes('Android')
    ? 'Android WebView (App)'
    : navigator.userAgent.substring(0, 35) + '...';

  try {
    localStorage.setItem('__test__', '1');
    localStorage.removeItem('__test__');
    infoStorage.textContent = 'فعال (Local + Session)';
  } catch (e) {
    infoStorage.textContent = 'غیرفعال';
    infoStorage.className = 'badge';
  }

  function updateOnlineStatus() {
    if (navigator.onLine) {
      infoOnline.textContent = 'متصل به شبکه';
      infoOnline.className = 'badge success';
    } else {
      infoOnline.textContent = 'آفلاین';
      infoOnline.className = 'badge';
    }
  }
  updateOnlineStatus();
  window.addEventListener('online', updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);
});
