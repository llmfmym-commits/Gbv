import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy
import groovy.json.JsonSlurper

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

val configFile = file("${rootDir}/app-config.json").takeIf { it.exists() }
    ?: file("${projectDir}/src/main/assets/app-config.json").takeIf { it.exists() }

val config: Map<String, Any?> = if (configFile != null && configFile.exists()) {
    try {
        @Suppress("UNCHECKED_CAST")
        JsonSlurper().parse(configFile) as Map<String, Any?>
    } catch (e: Exception) {
        emptyMap()
    }
} else {
    emptyMap()
}

val configAppName = (project.findProperty("appName") as? String)
    ?: (config["appName"] as? String)
    ?: "AirTube"

val configAppId = (project.findProperty("appId") as? String)
    ?: (config["appId"] as? String)
    ?: "com.example.airtube"

val configVersionName = (project.findProperty("versionName") as? String)
    ?: (config["versionName"] as? String)
    ?: "1.0.0"

val configVersionCode = (project.findProperty("versionCode") as? String)?.toIntOrNull()
    ?: (config["versionCode"] as? Number)?.toInt()
    ?: 1

val configSourceType = (project.findProperty("sourceType") as? String)
    ?: (config["sourceType"] as? String)
    ?: "URL"

val configAppUrl = (project.findProperty("appUrl") as? String)
    ?: (config["url"] as? String)
    ?: "https://example.com"

val configHtmlFile = (project.findProperty("htmlFile") as? String)
    ?: (config["htmlFile"] as? String)
    ?: "index.html"

@Suppress("UNCHECKED_CAST")
val tapsellConfig = config["tapsell"] as? Map<String, Any?> ?: emptyMap()

val configTapsellEnabled = (project.findProperty("tapsellEnabled") as? String)?.toBoolean()
    ?: (tapsellConfig["enabled"] as? Boolean)
    ?: false

val configTapsellAppKey = (project.findProperty("tapsellAppKey") as? String)
    ?: (tapsellConfig["appKey"] as? String)
    ?: ""

val configTapsellBannerZoneId = (project.findProperty("tapsellBannerZoneId") as? String)
    ?: (tapsellConfig["bannerZoneId"] as? String)
    ?: ""

val configTapsellInterstitialZoneId = (project.findProperty("tapsellInterstitialZoneId") as? String)
    ?: (tapsellConfig["interstitialZoneId"] as? String)
    ?: ""

val configTapsellRewardedZoneId = (project.findProperty("tapsellRewardedZoneId") as? String)
    ?: (tapsellConfig["rewardedZoneId"] as? String)
    ?: ""

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = configAppId
    minSdk = 24
    targetSdk = 36
    versionCode = configVersionCode
    versionName = configVersionName

    manifestPlaceholders["appName"] = configAppName
    manifestPlaceholders["appIcon"] = "@mipmap/ic_launcher"
    manifestPlaceholders["appRoundIcon"] = "@mipmap/ic_launcher_round"

    buildConfigField("String", "APP_NAME", "\"$configAppName\"")
    buildConfigField("String", "APP_ID", "\"$configAppId\"")
    buildConfigField("String", "VERSION_NAME", "\"$configVersionName\"")
    buildConfigField("int", "VERSION_CODE", "$configVersionCode")
    buildConfigField("String", "SOURCE_TYPE", "\"$configSourceType\"")
    buildConfigField("String", "APP_URL", "\"$configAppUrl\"")
    buildConfigField("String", "HTML_FILE", "\"$configHtmlFile\"")
    buildConfigField("boolean", "TAPSELL_ENABLED", "$configTapsellEnabled")
    buildConfigField("String", "TAPSELL_APP_KEY", "\"$configTapsellAppKey\"")
    buildConfigField("String", "TAPSELL_BANNER_ZONE_ID", "\"$configTapsellBannerZoneId\"")
    buildConfigField("String", "TAPSELL_INTERSTITIAL_ZONE_ID", "\"$configTapsellInterstitialZoneId\"")
    buildConfigField("String", "TAPSELL_REWARDED_ZONE_ID", "\"$configTapsellRewardedZoneId\"")

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    // GitHub Actions passes unset secrets as EMPTY strings, so blanks are treated as "not provided".
    fun envOrProp(name: String): String? =
        System.getenv(name)?.takeIf { it.isNotBlank() }
            ?: (project.findProperty(name) as? String)?.takeIf { it.isNotBlank() }

    val releaseKeystore: File? = envOrProp("KEYSTORE_PATH")
        ?.let { path -> File(path).let { f -> if (f.isAbsolute) f else rootProject.file(path) } }
        ?.takeIf { it.exists() }
        ?: rootProject.file("release.keystore").takeIf { it.exists() }

    create("release") {
      if (releaseKeystore != null) {
        storeFile = releaseKeystore
        storePassword = envOrProp("STORE_PASSWORD") ?: "android"
        keyAlias = envOrProp("KEY_ALIAS") ?: "androiddebugkey"
        keyPassword = envOrProp("KEY_PASSWORD") ?: "android"
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    // debug uses Android's automatic debug keystore (no custom file needed)
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  lint {
    checkReleaseBuilds = false
    abortOnError = false
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  implementation(libs.firebase.ai)
  // Uncomment to use Firestore:
  // implementation(libs.firebase.firestore)

  // Uncomment ALL FOUR of the following dependencies together to use Firebase Auth and Google
  // Sign-In via Credential Manager:
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  implementation(libs.firebase.appcheck.recaptcha)
  implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}
